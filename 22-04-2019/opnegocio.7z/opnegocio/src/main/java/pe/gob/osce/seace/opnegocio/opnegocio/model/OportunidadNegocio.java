package pe.gob.osce.seace.opnegocio.opnegocio.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;


/**
 * The persistent class for the TBL_OPORTUNIDAD_NEGOCIO database table.
 * 
 */
@Entity
@Table(name="TBL_OPORTUNIDAD_NEGOCIO", schema="PRO")
@NamedQuery(name="OportunidadNegocio.findAll", query="SELECT o FROM OportunidadNegocio o")
public class OportunidadNegocio implements Serializable {
	private static final long serialVersionUID = 1L;

	@Column(name="ID_PROCEDIMIENTO")
	private Long idProcedimiento;
	
	@Column(name="DET_ENTIDAD")
	private String detEntidad;
	
	@Column(name="COD_TIPO_PROCESO")
	private Integer codTipoProceso;
	
	@Column(name="DET_TIPO_PROCESO")
	private String detTipoProceso;
	
	@Column(name="COD_MODALIDAD_SELECCION")
	private String codModalidadSeleccion;
	
	@Column(name="DET_MODALIDAD_SELECCION")
	private String detModalidadSeleccion;
	
	@Column(name="NUM_PROCESO")
	private String numProceso;

	@Column(name="ANHO_PROCESO")
	private String anhoProceso;
	
	@Column(name="SIGLAS_PROCESO")
	private String siglasProceso;
	
	private String nomenclatura;
	
	@Column(name="COD_OBJETO")
	private Integer codObjeto;
	
	@Column(name="DET_OBJETO")
	private String detObjeto;
	
	@Column(name="VALOR_REFERENCIAL")
	private String valorReferencial;

	@Column(name="MONEDA_PROCESO")
	private String monedaProceso;

	@Column(name="FECHA_CONVOCATORIA")
	private String fechaConvocatoria;
	
	@Column(name="FECHA_INICIO")
	private String fechaInicio;

	@Column(name="FECHA_FIN")
	private String fechaFin;

	@Column(name="FECHA_PRESENTACION_PROPUESTAS")
	private String fechaPresentacionPropuestas;
	
	@Column(name="DOCUMENTO_BASE")
	private String documentoBase;
	
	private Long ubigeo;
	
	@Id
	@Column(name="ID_ITEM")
	private Long idItem;

	@Column(name="NRO_ITEM")
	private String nroItem;
	
	@Column(name="DET_ITEM")
	private String detItem;
	
	@Column(name="COD_CUBSO")
	private String codCubso;

	@Column(name="DET_CUBSO")
	private String detCubso;

	@Column(name="CANT_ITEM")
	private String cantItem;
	
	@Column(name="COD_UNIDAD_MEDIDA")
	private String codUnidadMedida;
	
	@Column(name="DET_UNIDAD_MEDIDA")
	private String detUnidadMedida;
	
	@Column(name="COD_MONEDA_ITEM")
	private Integer codMonedaItem;
	
	@Column(name="DET_MONEDA_ITEM")
	private String detMonedaItem;
	
	@Column(name="TIPO_CAMBIO")
	private String tipoCambio;
	
	@Column(name="VALOR_REFERENCIAL_ITEM")
	private String valorReferencialItem;
	
	@Column(name="TIPO_ITEM")
	private String tipoItem;
	
	@Column(name="ESTADO_ITEM")
	private String cEstadoItem;

	@Column(name="SINTESIS_PROCESO")
	private String sintesisProceso;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "D_FECINI")
	private Date fecInicioParticipantes;
	
	@Temporal(TemporalType.DATE)
	@Column(name = "D_FECFIN")
	private Date fecFinParticipantes;

	@Column(name="VERSION_SEACE")
	private String versionSeace;
	
	@Column(name="REINICIADO_DESDE")
	private String reiniciadoDesde;
	
	@Transient
	private String urlProceso;
	
	@Transient
	private String urlBases;
	
	@Transient
	private String estadoItem;

	public OportunidadNegocio() {
	}

	public String getAnhoProceso() {
		return anhoProceso;
	}

	public void setAnhoProceso(String anhoProceso) {
		this.anhoProceso = anhoProceso;
	}

	public String getCantItem() {
		return cantItem;
	}

	public void setCantItem(String cantItem) {
		this.cantItem = cantItem;
	}

	public String getCodCubso() {
		return codCubso;
	}

	public void setCodCubso(String codCubso) {
		this.codCubso = codCubso;
	}

	public String getcEstadoItem() {
		return cEstadoItem;
	}

	public void setcEstadoItem(String cEstadoItem) {
		this.cEstadoItem = cEstadoItem;
	}

	public String getCodModalidadSeleccion() {
		return codModalidadSeleccion;
	}

	public void setCodModalidadSeleccion(String codModalidadSeleccion) {
		this.codModalidadSeleccion = codModalidadSeleccion;
	}

	public Integer getCodMonedaItem() {
		return codMonedaItem;
	}

	public void setCodMonedaItem(Integer codMonedaItem) {
		this.codMonedaItem = codMonedaItem;
	}

	public Integer getCodObjeto() {
		return codObjeto;
	}

	public void setCodObjeto(Integer codObjeto) {
		this.codObjeto = codObjeto;
	}

	public Integer getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(Integer codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDetCubso() {
		return detCubso;
	}

	public void setDetCubso(String detCubso) {
		this.detCubso = detCubso;
	}

	public String getDetEntidad() {
		return detEntidad;
	}

	public void setDetEntidad(String detEntidad) {
		this.detEntidad = detEntidad;
	}

	public String getDetItem() {
		return detItem;
	}

	public void setDetItem(String detItem) {
		this.detItem = detItem;
	}

	public String getDetModalidadSeleccion() {
		return detModalidadSeleccion;
	}

	public void setDetModalidadSeleccion(String detModalidadSeleccion) {
		this.detModalidadSeleccion = detModalidadSeleccion;
	}

	public String getDetMonedaItem() {
		return detMonedaItem;
	}

	public void setDetMonedaItem(String detMonedaItem) {
		this.detMonedaItem = detMonedaItem;
	}

	public String getDetObjeto() {
		return detObjeto;
	}

	public void setDetObjeto(String detObjeto) {
		this.detObjeto = detObjeto;
	}

	public String getDetTipoProceso() {
		return detTipoProceso;
	}

	public void setDetTipoProceso(String detTipoProceso) {
		this.detTipoProceso = detTipoProceso;
	}

	public String getDetUnidadMedida() {
		return detUnidadMedida;
	}

	public void setDetUnidadMedida(String detUnidadMedida) {
		this.detUnidadMedida = detUnidadMedida;
	}

	public String getFechaConvocatoria() {
		return fechaConvocatoria;
	}

	public void setFechaConvocatoria(String fechaConvocatoria) {
		this.fechaConvocatoria = fechaConvocatoria;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaPresentacionPropuestas() {
		return fechaPresentacionPropuestas;
	}

	public void setFechaPresentacionPropuestas(String fechaPresentacionPropuestas) {
		this.fechaPresentacionPropuestas = fechaPresentacionPropuestas;
	}

	public Long getIdItem() {
		return idItem;
	}

	public void setIdItem(Long idItem) {
		this.idItem = idItem;
	}

	public Long getIdProcedimiento() {
		return idProcedimiento;
	}

	public void setIdProcedimiento(Long idProcedimiento) {
		this.idProcedimiento = idProcedimiento;
	}

	public String getMonedaProceso() {
		return monedaProceso;
	}

	public void setMonedaProceso(String monedaProceso) {
		this.monedaProceso = monedaProceso;
	}

	public String getNomenclatura() {
		return nomenclatura;
	}

	public void setNomenclatura(String nomenclatura) {
		this.nomenclatura = nomenclatura;
	}

	public String getNroItem() {
		return nroItem;
	}

	public void setNroItem(String nroItem) {
		this.nroItem = nroItem;
	}

	public String getNumProceso() {
		return numProceso;
	}

	public void setNumProceso(String numProceso) {
		this.numProceso = numProceso;
	}

	public String getSiglasProceso() {
		return siglasProceso;
	}

	public void setSiglasProceso(String siglasProceso) {
		this.siglasProceso = siglasProceso;
	}

	public String getSintesisProceso() {
		return sintesisProceso;
	}

	public void setSintesisProceso(String sintesisProceso) {
		this.sintesisProceso = sintesisProceso;
	}

	public String getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(String tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getTipoItem() {
		return tipoItem;
	}

	public void setTipoItem(String tipoItem) {
		this.tipoItem = tipoItem;
	}

	public Long getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(Long ubigeo) {
		this.ubigeo = ubigeo;
	}
	
	public String getDocumentoBase() {
		return documentoBase;
	}

	public void setDocumentoBase(String documentoBase) {
		this.documentoBase = documentoBase;
	}

	public String getValorReferencial() {
		return valorReferencial;
	}

	public void setValorReferencial(String valorReferencial) {
		this.valorReferencial = valorReferencial;
	}

	public String getValorReferencialItem() {
		return valorReferencialItem;
	}

	public void setValorReferencialItem(String valorReferencialItem) {
		this.valorReferencialItem = valorReferencialItem;
	}

	public String getVersionSeace() {
		return versionSeace;
	}

	public void setVersionSeace(String versionSeace) {
		this.versionSeace = versionSeace;
	}

	public Date getFecInicioParticipantes() {
		return fecInicioParticipantes;
	}

	public void setFecInicioParticipantes(Date fecInicioParticipantes) {
		this.fecInicioParticipantes = fecInicioParticipantes;
	}

	public Date getFecFinParticipantes() {
		return fecFinParticipantes;
	}

	public void setFecFinParticipantes(Date fecFinParticipantes) {
		this.fecFinParticipantes = fecFinParticipantes;
	}

	public String getUrlProceso() {
		return urlProceso;
	}

	public void setUrlProceso(String urlProceso) {
		this.urlProceso = urlProceso;
	}

	public String getEstadoItem() {
		return estadoItem;
	}

	public void setEstadoItem(String estadoItem) {
		this.estadoItem = estadoItem;
	}

	public String getUrlBases() {
		return urlBases;
	}

	public void setUrlBases(String urlBases) {
		this.urlBases = urlBases;
	}

	public String getReiniciadoDesde() {
		return reiniciadoDesde;
	}

	public void setReiniciadoDesde(String reiniciadoDesde) {
		this.reiniciadoDesde = reiniciadoDesde;
	}

}