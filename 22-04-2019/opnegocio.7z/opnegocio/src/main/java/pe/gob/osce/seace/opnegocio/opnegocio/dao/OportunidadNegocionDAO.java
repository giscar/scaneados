package pe.gob.osce.seace.opnegocio.opnegocio.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;

public interface OportunidadNegocionDAO extends JpaRepository<OportunidadNegocio, Long>{
	
	public Page<OportunidadNegocio> findByCodObjetoEquals(Pageable pageable, Integer codigoObjeto);
	
	

}
