package pe.gob.osce.seace.opnegocio.opnegocio.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TBL_OPN_SUGERENCIAS",schema="PRO")
public class Sugerencia implements Serializable
{
		private static final long serialVersionUID = 1L;

		@Id
		@Column(name="N_ID_SUGERENCIA")
		@SequenceGenerator(name="SQ_OPN_SUGERENCIA", sequenceName="SQ_OPN_SUGERENCIA", allocationSize = 1)
	    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SQ_OPN_SUGERENCIA")
		private Long id;

		@Column(name="C_LISTA")
		private String lista;

		@Column(name="C_EMAIL")
		private String email;
		
		@Column(name="C_COMENTARIO")
		private String comentario;

		
		@Column(name="D_FECHA_REGISTRO")
		private Date fecha;


		public Long getId() {
			return id;
		}


		public void setId(Long id) {
			this.id = id;
		}


		public String getLista() {
			return lista;
		}


		public void setLista(String lista) {
			this.lista = lista;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getComentario() {
			return comentario;
		}


		public void setComentario(String comentario) {
			this.comentario = comentario;
		}


		public Date getFecha() {
			return fecha;
		}


		public void setFecha(Date fecha) {
			this.fecha = fecha;
		}


		
	
}
