package pe.gob.osce.seace.opnegocio.opnegocio.dao;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;

public interface OportunidadNegocionDAO extends CrudRepository<OportunidadNegocio, Long>{
	
	public List<OportunidadNegocio> findByCodObjetoEquals(Integer codigoObjeto);

}
