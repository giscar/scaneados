package pe.gob.osce.seace.opnegocio.opnegocio.dao;

import org.springframework.data.repository.CrudRepository;

import pe.gob.osce.seace.opnegocio.opnegocio.model.Sugerencia;

public interface SugerenciaDAO extends CrudRepository<Sugerencia, Long>{

}
