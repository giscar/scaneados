package pe.gob.osce.seace.opnegocio.opnegocio.service;

import java.util.List;

import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;
import pe.gob.osce.seace.opnegocio.opnegocio.model.Sugerencia;


public interface OportunidadNegocioService {
	
	public List<OportunidadNegocio> findAll();
	
	public Sugerencia guardarSugerencia(Sugerencia sugerencia);
	
	public List<OportunidadNegocio> findByFilter(OportunidadNegocio oportunidadNegocio);
	
	public List<OportunidadNegocio> findByCodObjetoEquals(Integer codigoObjeto);

}
