package pe.gob.osce.seace.opnegocio.opnegocio.dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;

public interface OportunidadNegocionDAO extends JpaRepository<OportunidadNegocio, Long>{
	
	@Query(value="SELECT o FROM OportunidadNegocio o where 1 = 1 "
			+ "AND ( :codigoObjeto = 0 OR o.codObjeto = :codigoObjeto ) "
			+ "AND ( :detItem = '0' OR UPPER(o.detItem) like CONCAT('%', :detItem, '%') ) ")
	public Page<OportunidadNegocio> findByQuery(Pageable pageable, @Param("codigoObjeto") Integer codigoObjeto, @Param("detItem") String detItem);
	
	

}
