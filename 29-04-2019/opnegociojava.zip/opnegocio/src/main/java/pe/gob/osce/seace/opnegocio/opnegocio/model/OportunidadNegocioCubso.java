package pe.gob.osce.seace.opnegocio.opnegocio.model;

import java.io.Serializable;
import javax.persistence.*;


/**
 * The persistent class for the TBL_OPORTUNIDAD_NEGOCIO_CUBSO database table.
 * 
 */
@Entity
@Table(name="TBL_OPORTUNIDAD_NEGOCIO_CUBSO",schema="OPN")
@NamedQuery(name="OportunidadNegocioCubso.findAll", query="SELECT o FROM OportunidadNegocioCubso o")
public class OportunidadNegocioCubso implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="CODIGO_SEGMENTO")
	private String codigoSegmento;

	@Column(name="CANTIDAD_PROCESOS")
	private String cantidadProcesos;

	@Column(name="TITULO_SEGMENTO")
	private String tituloSegmento;

	public OportunidadNegocioCubso() {
	}

	public String getCodigoSegmento() {
		return this.codigoSegmento;
	}

	public void setCodigoSegmento(String codigoSegmento) {
		this.codigoSegmento = codigoSegmento;
	}

	public String getCantidadProcesos() {
		return this.cantidadProcesos;
	}

	public void setCantidadProcesos(String cantidadProcesos) {
		this.cantidadProcesos = cantidadProcesos;
	}

	public String getTituloSegmento() {
		return this.tituloSegmento;
	}

	public void setTituloSegmento(String tituloSegmento) {
		this.tituloSegmento = tituloSegmento;
	}

}