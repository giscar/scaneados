package pe.gob.osce.seace.opnegocio.opnegocio.service;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;
import pe.gob.osce.seace.opnegocio.opnegocio.model.Sugerencia;


public interface OportunidadNegocioService {
	
	public List<OportunidadNegocio> findAll();
	
	public Sugerencia guardarSugerencia(Sugerencia sugerencia);
	
	public List<OportunidadNegocio> findByFilter(OportunidadNegocio oportunidadNegocio);
	
	public Page<OportunidadNegocio> findByCodObjetoEquals(Pageable pageable, Integer codigoObjeto, String detItem);
	
	public Page<OportunidadNegocio> findAll(Pageable pageable) ;

}
