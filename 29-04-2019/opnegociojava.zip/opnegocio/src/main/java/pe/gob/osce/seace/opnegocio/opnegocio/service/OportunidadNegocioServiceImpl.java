package pe.gob.osce.seace.opnegocio.opnegocio.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.ResponseStatus;

import pe.gob.osce.seace.opnegocio.opnegocio.dao.OportunidadNegocionDAO;
import pe.gob.osce.seace.opnegocio.opnegocio.dao.SugerenciaDAO;
import pe.gob.osce.seace.opnegocio.opnegocio.model.OportunidadNegocio;
import pe.gob.osce.seace.opnegocio.opnegocio.model.Sugerencia;

@Service
public class OportunidadNegocioServiceImpl implements OportunidadNegocioService{
	
	@Autowired
	private OportunidadNegocionDAO oportunidadNegocioDao;
	
	@Autowired
	private SugerenciaDAO sugerenciaDAO;

	@Override
	@Transactional(readOnly = true)
	public List<OportunidadNegocio> findAll() {
		return (List<OportunidadNegocio>) oportunidadNegocioDao.findAll();
		 
	}

	@Override
	@Transactional
	public Sugerencia guardarSugerencia(Sugerencia sugerencia) {
		return sugerenciaDAO.save(sugerencia);
	}

	@Override
	@Transactional(readOnly = true)
	public List<OportunidadNegocio> findByFilter(OportunidadNegocio oportunidadNegocio) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	@Transactional(readOnly = true)
	public Page<OportunidadNegocio> findByCodObjetoEquals(Pageable pageable, Integer codigoObjeto, String detItem) {
		System.out.println(codigoObjeto);
		System.out.println(detItem);
		return oportunidadNegocioDao.findByQuery(pageable, codigoObjeto, detItem);
	}

	@Override
	@Transactional(readOnly = true)
	public Page<OportunidadNegocio> findAll(Pageable pageable) {
		return oportunidadNegocioDao.findAll(pageable);
	}

	
	
	
	

}
