package pe.gob.osce.seace.opnegocio.opnegocio.dto;

import java.util.Date;

public class OportunidadNegocioDTO {

	private Long idProcedimiento;
	
	private String detEntidad;
	
	private Integer codTipoProceso;
	
	private String detTipoProceso;
	
	private String codModalidadSeleccion;
	
	private String detModalidadSeleccion;
	
	private String numProceso;

	private String anhoProceso;
	
	private String siglasProceso;
	
	private String nomenclatura;
	
	private Integer codObjeto;
	
	private String detObjeto;
	
	private String valorReferencial;

	private String monedaProceso;
	
	private String fechaConvocatoria;
	
	private String fechaInicio;

	private String fechaFin;

	private String fechaPresentacionPropuestas;
	
	private String documentoBase;
	
	private Long ubigeo;
	
	private Long idItem;

	private String nroItem;
	
	private String detItem;
	
	private String codCubso;

	private String detCubso;
	
	private String cantItem;
	
	private String codUnidadMedida;
	
	private String detUnidadMedida;
	
	private Integer codMonedaItem;
	
	private String detMonedaItem;
	
	private String tipoCambio;
	
	private String valorReferencialItem;
	
	private String tipoItem;
	
	private String cEstadoItem;

	private String sintesisProceso;
	
	private Date fecInicioParticipantes;
	
	private Date fecFinParticipantes;

	private String versionSeace;
	
	private String reiniciadoDesde;
	
	private String urlProceso;
	
	private String urlBases;
	
	private String estadoItem;

	public OportunidadNegocioDTO() {
	}

	public String getAnhoProceso() {
		return anhoProceso;
	}

	public void setAnhoProceso(String anhoProceso) {
		this.anhoProceso = anhoProceso;
	}

	public String getCantItem() {
		return cantItem;
	}

	public void setCantItem(String cantItem) {
		this.cantItem = cantItem;
	}

	public String getCodCubso() {
		return codCubso;
	}

	public void setCodCubso(String codCubso) {
		this.codCubso = codCubso;
	}

	public String getcEstadoItem() {
		return cEstadoItem;
	}

	public void setcEstadoItem(String cEstadoItem) {
		this.cEstadoItem = cEstadoItem;
	}

	public String getCodModalidadSeleccion() {
		return codModalidadSeleccion;
	}

	public void setCodModalidadSeleccion(String codModalidadSeleccion) {
		this.codModalidadSeleccion = codModalidadSeleccion;
	}

	public Integer getCodMonedaItem() {
		return codMonedaItem;
	}

	public void setCodMonedaItem(Integer codMonedaItem) {
		this.codMonedaItem = codMonedaItem;
	}

	public Integer getCodObjeto() {
		return codObjeto;
	}

	public void setCodObjeto(Integer codObjeto) {
		this.codObjeto = codObjeto;
	}

	public Integer getCodTipoProceso() {
		return codTipoProceso;
	}

	public void setCodTipoProceso(Integer codTipoProceso) {
		this.codTipoProceso = codTipoProceso;
	}

	public String getCodUnidadMedida() {
		return codUnidadMedida;
	}

	public void setCodUnidadMedida(String codUnidadMedida) {
		this.codUnidadMedida = codUnidadMedida;
	}

	public String getDetCubso() {
		return detCubso;
	}

	public void setDetCubso(String detCubso) {
		this.detCubso = detCubso;
	}

	public String getDetEntidad() {
		return detEntidad;
	}

	public void setDetEntidad(String detEntidad) {
		this.detEntidad = detEntidad;
	}

	public String getDetItem() {
		return detItem;
	}

	public void setDetItem(String detItem) {
		this.detItem = detItem;
	}

	public String getDetModalidadSeleccion() {
		return detModalidadSeleccion;
	}

	public void setDetModalidadSeleccion(String detModalidadSeleccion) {
		this.detModalidadSeleccion = detModalidadSeleccion;
	}

	public String getDetMonedaItem() {
		return detMonedaItem;
	}

	public void setDetMonedaItem(String detMonedaItem) {
		this.detMonedaItem = detMonedaItem;
	}

	public String getDetObjeto() {
		return detObjeto;
	}

	public void setDetObjeto(String detObjeto) {
		this.detObjeto = detObjeto;
	}

	public String getDetTipoProceso() {
		return detTipoProceso;
	}

	public void setDetTipoProceso(String detTipoProceso) {
		this.detTipoProceso = detTipoProceso;
	}

	public String getDetUnidadMedida() {
		return detUnidadMedida;
	}

	public void setDetUnidadMedida(String detUnidadMedida) {
		this.detUnidadMedida = detUnidadMedida;
	}

	public String getFechaConvocatoria() {
		return fechaConvocatoria;
	}

	public void setFechaConvocatoria(String fechaConvocatoria) {
		this.fechaConvocatoria = fechaConvocatoria;
	}

	public String getFechaFin() {
		return fechaFin;
	}

	public void setFechaFin(String fechaFin) {
		this.fechaFin = fechaFin;
	}

	public String getFechaInicio() {
		return fechaInicio;
	}

	public void setFechaInicio(String fechaInicio) {
		this.fechaInicio = fechaInicio;
	}

	public String getFechaPresentacionPropuestas() {
		return fechaPresentacionPropuestas;
	}

	public void setFechaPresentacionPropuestas(String fechaPresentacionPropuestas) {
		this.fechaPresentacionPropuestas = fechaPresentacionPropuestas;
	}

	public Long getIdItem() {
		return idItem;
	}

	public void setIdItem(Long idItem) {
		this.idItem = idItem;
	}

	public Long getIdProcedimiento() {
		return idProcedimiento;
	}

	public void setIdProcedimiento(Long idProcedimiento) {
		this.idProcedimiento = idProcedimiento;
	}

	public String getMonedaProceso() {
		return monedaProceso;
	}

	public void setMonedaProceso(String monedaProceso) {
		this.monedaProceso = monedaProceso;
	}

	public String getNomenclatura() {
		return nomenclatura;
	}

	public void setNomenclatura(String nomenclatura) {
		this.nomenclatura = nomenclatura;
	}

	public String getNroItem() {
		return nroItem;
	}

	public void setNroItem(String nroItem) {
		this.nroItem = nroItem;
	}

	public String getNumProceso() {
		return numProceso;
	}

	public void setNumProceso(String numProceso) {
		this.numProceso = numProceso;
	}

	public String getSiglasProceso() {
		return siglasProceso;
	}

	public void setSiglasProceso(String siglasProceso) {
		this.siglasProceso = siglasProceso;
	}

	public String getSintesisProceso() {
		return sintesisProceso;
	}

	public void setSintesisProceso(String sintesisProceso) {
		this.sintesisProceso = sintesisProceso;
	}

	public String getTipoCambio() {
		return tipoCambio;
	}

	public void setTipoCambio(String tipoCambio) {
		this.tipoCambio = tipoCambio;
	}

	public String getTipoItem() {
		return tipoItem;
	}

	public void setTipoItem(String tipoItem) {
		this.tipoItem = tipoItem;
	}

	public Long getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(Long ubigeo) {
		this.ubigeo = ubigeo;
	}
	
	public String getDocumentoBase() {
		return documentoBase;
	}

	public void setDocumentoBase(String documentoBase) {
		this.documentoBase = documentoBase;
	}

	public String getValorReferencial() {
		return valorReferencial;
	}

	public void setValorReferencial(String valorReferencial) {
		this.valorReferencial = valorReferencial;
	}

	public String getValorReferencialItem() {
		return valorReferencialItem;
	}

	public void setValorReferencialItem(String valorReferencialItem) {
		this.valorReferencialItem = valorReferencialItem;
	}

	public String getVersionSeace() {
		return versionSeace;
	}

	public void setVersionSeace(String versionSeace) {
		this.versionSeace = versionSeace;
	}

	public Date getFecInicioParticipantes() {
		return fecInicioParticipantes;
	}

	public void setFecInicioParticipantes(Date fecInicioParticipantes) {
		this.fecInicioParticipantes = fecInicioParticipantes;
	}

	public Date getFecFinParticipantes() {
		return fecFinParticipantes;
	}

	public void setFecFinParticipantes(Date fecFinParticipantes) {
		this.fecFinParticipantes = fecFinParticipantes;
	}

	public String getUrlProceso() {
		return urlProceso;
	}

	public void setUrlProceso(String urlProceso) {
		this.urlProceso = urlProceso;
	}

	public String getEstadoItem() {
		return estadoItem;
	}

	public void setEstadoItem(String estadoItem) {
		this.estadoItem = estadoItem;
	}

	public String getUrlBases() {
		return urlBases;
	}

	public void setUrlBases(String urlBases) {
		this.urlBases = urlBases;
	}

	public String getReiniciadoDesde() {
		return reiniciadoDesde;
	}

	public void setReiniciadoDesde(String reiniciadoDesde) {
		this.reiniciadoDesde = reiniciadoDesde;
	}

}