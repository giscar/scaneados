package pe.gob.osce.seace.opnegocio.opnegocio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpnegocioApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpnegocioApplication.class, args);
	}

}
